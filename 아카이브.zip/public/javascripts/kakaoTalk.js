$(document).ready(function(){
	$('#send').on('click',isBlank);
	function isBlank(){
	  if($('textarea').val() === ''){
	    alert('메시지 입력');
	  }else{
	    $('.chatbox').append('<div class=\'my-bubble bubble\'>'+ $('textarea').val() +'</div>');
	    $('textarea').val('');
	  }
	}
})